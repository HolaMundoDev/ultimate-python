numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Feo!
# primero = numeros[0]
# segundo = numeros[1]
# primero = numeros[2]

primero, segundo, *otros, penultimo, ultimo = numeros
print(segundo, penultimo, otros)
