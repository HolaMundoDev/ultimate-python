try:
    n1 = int(input("Ingresa primer número: "))
except:
    print("ocurrió un error :(")
