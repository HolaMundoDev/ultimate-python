curso = "Ultimate \nPython\""
print(curso)
