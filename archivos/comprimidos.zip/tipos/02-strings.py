nombre_curso = "Ultimate Python"
descripcion_curso = """
Ultimate Python, 
este curso contempla todos los detalles
que necesitas aprender para encontrar
un trabajo como programador.
"""

print(len(nombre_curso))
print(nombre_curso[0])
print(nombre_curso[0:8])
print(nombre_curso[9:])
print(nombre_curso[:8])
print(nombre_curso[:])
