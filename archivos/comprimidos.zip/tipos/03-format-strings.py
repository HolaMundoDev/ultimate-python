nombre = "Nicolas"
apellido = "Schurmann"
nombre_completo = f"{nombre[0]} {2 + 5}"
print(nombre_completo)
