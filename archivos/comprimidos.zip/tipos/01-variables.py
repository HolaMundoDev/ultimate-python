nombre_curso = "Ultimate Python"
nombre1 = "Hola"
NOMBRE_CURSO = "Mundo"
NoMbRe_CuRsO = "Chanchito"
NombreCurso = "Feliz"
print(nombre_curso, nombre1, NOMBRE_CURSO)
