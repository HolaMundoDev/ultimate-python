edad = 19

mensaje = "Es mayor" if edad > 17 else "Es menor"

# if edad > 17:
#     mensaje = "Es mayor"
# else:
#     mensaje = "Es menor"

print(mensaje)
