# and, or, not

gas = False
encendido = True
edad = 18

if not gas or encendido or edad > 17:
    print("Puedes avanzar")
