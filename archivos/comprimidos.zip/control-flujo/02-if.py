edad = 70

if edad > 65:
    print("Puede ver la película con super descuento")
elif edad > 54:
    print("Puede ver la película con descuento")
elif edad > 17:
    print("Puede ver la película")
# else:
#     print("No puedes entrar")
#     print("Ve a otro lado")

print("listo")
