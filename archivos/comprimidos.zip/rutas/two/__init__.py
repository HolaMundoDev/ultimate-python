def init(db, api, **otros):
    print(f"soy paquete dos: {db} {api}")
