"""Ultimate Python"""
print("Hola Mundo!")
print("El weta " * 4 )
