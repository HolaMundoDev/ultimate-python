def suma(a, b):
    resultado = a + b
    return resultado


c = suma(1, 2)
d = suma(c, 2)

print(d)
