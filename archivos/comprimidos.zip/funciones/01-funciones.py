def hola(nombre, apellido="Feliz"):
    print("Hola Mundo!")
    print(f"Bienvenido {nombre} {apellido}")

hola(apellido="Schurmann", nombre="Wolfgang")
hola("Chanchito")